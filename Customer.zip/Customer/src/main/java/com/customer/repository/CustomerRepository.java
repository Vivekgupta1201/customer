package com.customer.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.customer.model.CustomerLoginModel;
import com.customer.model.CustomerLoginResponseModel;
import com.customer.model.CustomerModel;

@Repository
public class CustomerRepository {

	private List<CustomerModel> list = new ArrayList<CustomerModel>();

	public void createCustomerDetails() {
		list = List
				.of(new CustomerModel("Rajesh", "Kumar", "Bihiya", "Bhojpur", "Bihar", "abc@gmail.com", "1234567890"));
	}

	public List<CustomerModel> getAllCustomers() {
		return list;
	}

	public CustomerModel save(CustomerModel p) {
		CustomerModel customer = new CustomerModel();
		customer.setFirstName(p.getFirstName());
		customer.setLastName(p.getLastName());
		customer.setAddress(p.getAddress());
		customer.setCity(p.getCity());
		customer.setState(p.getState());
		customer.setEmailId(p.getEmailId());
		customer.setPhone(p.getPhone());
		list.add(customer);
		return customer;
	}
	
	public String delete(String phone) {
        list.removeIf(x -> x.getPhone() .equals(phone));
        return "OK";
    }

	public CustomerLoginResponseModel login(CustomerLoginModel customerLoginModel) {
		System.out.println(customerLoginModel);
		if(customerLoginModel.getLogin_id().equals("admin") && customerLoginModel.getPassword().equals("admin123")) {
			return new CustomerLoginResponseModel("Successfully logged in!", "OK");
		}
		return new CustomerLoginResponseModel("Login failed!", "FAILED");
	}
}
