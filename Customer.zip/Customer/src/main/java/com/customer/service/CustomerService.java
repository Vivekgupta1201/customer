package com.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.model.CustomerLoginModel;
import com.customer.model.CustomerLoginResponseModel;
import com.customer.model.CustomerModel;
import com.customer.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	public CustomerLoginResponseModel loginCustomer(CustomerLoginModel customerLoginModel) {
		return customerRepository.login(customerLoginModel);
	}

	public List<CustomerModel> getCustomers() {
		return customerRepository.getAllCustomers();
	}
	
	public CustomerModel saveProduct(CustomerModel customer) {
		return customerRepository.save(customer);
	}

	public String deleteProduct(String phone) {
		customerRepository.delete(phone);
		return phone;
	}
}
