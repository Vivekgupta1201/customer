package com.customer.model;

import lombok.Data;

@Data
public class CustomerLoginResponseModel {
	private String message;
	private String status;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public CustomerLoginResponseModel(String message, String status) {
		super();
		this.message = message;
		this.status = status;
	}

}
